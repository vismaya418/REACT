import React from 'react'

function About() {
  return (
    <div>
        <h2>This is About Page</h2>
    </div>
  )
}

export default About