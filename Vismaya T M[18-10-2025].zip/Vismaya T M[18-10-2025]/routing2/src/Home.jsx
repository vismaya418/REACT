import React from 'react'

function Home() {
  return (
     <h2>This is Home Page</h2>
  )
}

export default Home