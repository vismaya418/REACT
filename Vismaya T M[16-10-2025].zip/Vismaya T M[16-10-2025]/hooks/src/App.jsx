import React from 'react'
import Example from './hooks';
import Counter from './Counter';

function App() {
  return (
    <div>
      <Example/>
      <Counter/>
    </div>
  )
}

export default App;