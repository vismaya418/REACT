import React from 'react'

function Pass() {
  return (<div>Congratulations</div>)
}

function Fail() {
  return (<div>Better Luck Next Time</div>)
}

/*function ClassResult(props) {
  const isresult = props.isresult;
 console.log(isresult)
  if (isresult===true) {
    return <Pass/>;
  }
  if(isresult===false){
  return <Fail/>;
}
}*/
function ClassResult(props){
    const isresult=props.isresult;
    return(
        <>
        {isresult ? <Pass/>:<Fail/>}
        </>
    )
}
export default ClassResult
