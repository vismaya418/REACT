import React from 'react'

import ClassResult from './ConditionalRendering'

function App() {

  return (
  <div>
    
    <ClassResult isresult={true} />
  </div>
  )
}

export default App