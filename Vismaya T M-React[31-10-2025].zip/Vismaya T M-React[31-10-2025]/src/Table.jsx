import React from 'react'

function Table() {
    const stylerow1={
         backgroundColor:"yellow",
         color:"blue"
        
    }
    const cell1={
        border:"2px solid #000",
        padding:"10px",
    }
     const stylerow2={
        backgroundColor:"blue",
         color:"white"
        
    }
    const cell2={
        border:"2px solid #000",
        padding:"10px",
    }
  return (
   <>
   <tr style={stylerow1}>
    <td style={cell1}>Vismaya T M</td>
    <td>React Developer</td>
   </tr>
   <tr style={stylerow2}>
    <td style={cell2}>Bimba M</td>
    <td style={cell2}>Designer</td>
   </tr>
   </>
  )
}

export default Table