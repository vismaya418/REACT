import React, { useState } from 'react';
import Modal from './Modal';

function App() {
  const [showModal, setShowModal] = useState(false);

  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h2>Main App Content</h2>
      <button
        style={{
          background: "#007BFF",
          color: "white",
          padding: "10px 20px",
          border: "none",
          borderRadius: "50px",
          cursor: "pointer",
          fontSize: "16px"
        }}
        onClick={() => setShowModal(true)}
      >
        Show Modal
      </button>

      {showModal && (
        <Modal onClose={() => setShowModal(false)}>
          <h2>This is rendered via a Portal!</h2>
        </Modal>
      )}
    </div>
  );
}

export default App;
