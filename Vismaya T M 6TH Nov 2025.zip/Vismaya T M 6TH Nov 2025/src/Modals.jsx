import { createPortal } from "react-dom"
function Modals({children}){
    return createPortal(
   <div className="modal">{children}</div>,
   document.getElementById("modal-root")
    
    )

}
export default Modals