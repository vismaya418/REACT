import React from 'react'
import Modals from './Modals'
import { useState } from 'react';
function App(){
  const [open, setOpen]=useState(false);
  return(
  <>
{/* <div style={{backgroundColor:"red"}}>
<h2>Vismaya</h2>
<p>React Developer</p>
</div>
<React.Fragment>
  <div style={{backgroundColor:"blue",color:"white"}}>
<h2>Nisha</h2>
<p>React Developer</p>
</div>
</React.Fragment> */}
<button onClick={()=>setOpen(true)} style={{backgroundColor:"yellow"}}>Open Modal</button>
{open && (<Modals>
  <>
    <div style={{backgroundColor:"pink"}}>Hello This is Notification</div>
    <div>
        <button onClick={()=>setOpen(false)} style={{backgroundColor:"orange"}}>Close</button>
    </div>
    </> 
</Modals>)}
  </>
  )
}
export default App