import React from 'react'

function FirstComponent(vismaya) {
  return (
    <div><h1>FirstComponent{vismaya.name}</h1>
    <SecondComponent phno="9999900000"/>
    </div>
  )
}
function SecondComponent(vismaya) {
  return (
    <div>SecondComponent{vismaya.phno}</div>
  )
}
export default FirstComponent