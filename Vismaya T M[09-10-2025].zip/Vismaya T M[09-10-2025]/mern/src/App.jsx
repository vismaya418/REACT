import React from 'react'
import FirstComponent from './FirstComponent'
import Fruit from './ClassOne'

function App() {

  return (
  <div>
    <FirstComponent name="vismaya"/>
    <FirstComponent name="vismaya"/>
    <FirstComponent name="vismaya"/>
    <Fruit/>
    <Fruit></Fruit>
  </div>
  )
}

export default App
