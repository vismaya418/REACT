import { useBattery } from "@uidotdev/usehooks";

export default function BatteryInfo() {
  const { loading, level, charging, chargingTime, dischargingTime } =
    useBattery();

  return (
    <div className="wrapper">
      <h1>useBattery</h1>
      {!loading ? (
        <div>
          <p>Battery Level: {(level * 100).toFixed(0)}%</p>
          <p>Status: {charging ? "Charging" : "Discharging"}</p>
          {charging ? (
            <p>Charging Time: {Math.round(chargingTime / 60)} minutes</p>
          ) : (
            <p>Discharging Time: {Math.round(dischargingTime / 60)} minutes</p>
          )}
        </div>
      ) : (
        <h2>Loading...</h2>
      )}
    </div>
  );
}
