import React from 'react'
import Component1 from './ContextApi'
import Ref from './Ref'
import AccesingDom from './AccesingDom'
import Track from './Track'
import BatteryInfo from './Battery'
function App() {
  return (
    <div>
       {/* <Component1/>  
       <Ref/> 
       <AccesingDom/> 
       <Track/> */}
      <BatteryInfo/>
    </div>
  )
}

export default App