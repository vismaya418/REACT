import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Hello from './helloworld'

function App() {
  

  return (
    
   <div>
     <h1>Hello World</h1>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quaerat iste deserunt officia ex consectetur consequuntur incidunt ut numquam explicabo iusto exercitationem, accusantium recusandae fugit atque aut vel dolor! Culpa, ex?</p>
    <Hello />
   </div>
  )


}

export default App
