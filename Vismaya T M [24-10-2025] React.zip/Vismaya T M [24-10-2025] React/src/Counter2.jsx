import React,{ useReducer} from "react";
function Counter2(){
    //1.Define the reducer function
    function reducer(state,action){
        switch(action.type){
            case "INCREMENT":
                return{count:state.count+1};
            case "INCREMENT BY TWO":
                return{count:state.count+2};
            case "DECREMENT":
                return{count:state.count-1};
            case "RESET":
                return{count:0};
            default:
                return state;
        }
    }
    const[state,dispatch]=useReducer(reducer,{count:0});
    //3.UI with dispatch actions
    return(
        <div style={{textAlign:"center",marginTop:"50px"}}>
            <h2>Count:{state.count}</h2>
            <button onClick={()=>dispatch({type:"INCREMENT"})}>+Increment</button>
             <button onClick={()=>dispatch({type:"INCREMENT BY TWO"})}>+Increment By 2</button>
            <button onClick={()=>dispatch({type:"DECREMENT"})}>-Decrement</button>
            <button onClick={()=>dispatch({type:"RESET"})}>Reset</button>
        </div>
    )
}
export default Counter2;