import React from 'react'
import Component1 from './ContextApi'
import Ref from './Ref'
import AccesingDom from './AccesingDom'
import Track from './Track'

import Counter from './Reducer'
import Counter2 from './Counter2'
import WithUseMemo from './UseMemo'
import Parent from './CallBack'
import CounterApp from './CounterApp'
function App() {
  return (
    <div>
       {/* <Component1/>  
       <Ref/> 
       <AccesingDom/> 
       <Track/> 
     
      <Counter/>
      <Counter2/>  
      <WithUseMemo/> 
      <Parent/> */}
      <CounterApp/>
    </div>
  )
}

export default App