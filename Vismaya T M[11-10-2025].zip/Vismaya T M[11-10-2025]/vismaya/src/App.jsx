import React from 'react'
import HtmlForms from './HtmlForms'
import ControlledForm from './ControlledForm'
function App() {
  return (
    <div>
       <HtmlForms/>
       <ControlledForm/>
    </div>
    
  )
}
 
export default App